#include <iostream>

using namespace std;

int main() {
  cout << "Testing...";
  cout << " PASSED" << endl;
  return 0;
}

